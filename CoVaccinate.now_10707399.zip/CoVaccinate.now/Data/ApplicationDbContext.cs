﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CoVaccinate.now.Models;
using Microsoft.AspNetCore.Identity;

namespace CoVaccinate.now.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
        public DbSet<CoVaccinate.now.Models.Vaccine> Vaccine { get; set; }
        public DbSet<CoVaccinate.now.Models.VaccineDose> VaccineDose { get; set; }
        public DbSet<CoVaccinate.now.Models.AgeGroup> AgeGroup { get; set; }
        public DbSet<CoVaccinate.now.Models.VaccineCentre> VaccineCentre { get; set; }
        public DbSet<CoVaccinate.now.Models.AppointmentModel> AppointmentModel { get; set; }
        public DbSet<CoVaccinate.now.Models.Quota> Quota { get; set; }
        public DbSet<CoVaccinate.now.Models.Report> Report { get; set; }
 
       
    }
}
