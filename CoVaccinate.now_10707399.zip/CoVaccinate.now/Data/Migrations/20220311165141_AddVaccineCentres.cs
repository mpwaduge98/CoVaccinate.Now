﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CoVaccinate.now.Data.Migrations
{
    public partial class AddVaccineCentres : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "VaccineCentre",
                columns: table => new
                {
                    VaccineCentreId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VaccineCentreName = table.Column<string>(nullable: false),
                    Address = table.Column<string>(nullable: false),
                    ZIPCode = table.Column<string>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    PhoneNo = table.Column<int>(nullable: false),
                    longitude = table.Column<string>(nullable: true),
                    latitude = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VaccineCentre", x => x.VaccineCentreId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "VaccineCentre");
        }
    }
}
