﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CoVaccinate.now.Data.Migrations
{
    public partial class addednewcolumn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "SpecialNote",
                table: "Vaccine",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SpecialNote",
                table: "Vaccine");
        }
    }
}
