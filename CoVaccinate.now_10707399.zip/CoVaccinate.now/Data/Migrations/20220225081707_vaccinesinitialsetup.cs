﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CoVaccinate.now.Data.Migrations
{
    public partial class vaccinesinitialsetup : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AgeGroup",
                columns: table => new
                {
                    AgeGroupId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RecommendedAgeGroup = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AgeGroup", x => x.AgeGroupId);
                });

            migrationBuilder.CreateTable(
                name: "VaccineDose",
                columns: table => new
                {
                    VaccineDoseId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VaccineDoses = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VaccineDose", x => x.VaccineDoseId);
                });

            migrationBuilder.CreateTable(
                name: "Vaccine",
                columns: table => new
                {
                    VaccineID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VaccineName = table.Column<string>(nullable: false),
                    AgeGroupId = table.Column<int>(nullable: false),
                    VaccineDoseId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vaccine", x => x.VaccineID);
                    table.ForeignKey(
                        name: "FK_Vaccine_AgeGroup_AgeGroupId",
                        column: x => x.AgeGroupId,
                        principalTable: "AgeGroup",
                        principalColumn: "AgeGroupId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Vaccine_VaccineDose_VaccineDoseId",
                        column: x => x.VaccineDoseId,
                        principalTable: "VaccineDose",
                        principalColumn: "VaccineDoseId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Vaccine_AgeGroupId",
                table: "Vaccine",
                column: "AgeGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Vaccine_VaccineDoseId",
                table: "Vaccine",
                column: "VaccineDoseId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Vaccine");

            migrationBuilder.DropTable(
                name: "AgeGroup");

            migrationBuilder.DropTable(
                name: "VaccineDose");
        }
    }
}
