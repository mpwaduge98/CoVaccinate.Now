﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CoVaccinate.now.Data.Migrations
{
    public partial class AddQuotasTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Quota",
                columns: table => new
                {
                    QuotaID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VaccineCentreId = table.Column<int>(nullable: false),
                    OpenDays = table.Column<string>(nullable: false),
                    OpenHours = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Quota", x => x.QuotaID);
                    table.ForeignKey(
                        name: "FK_Quota_VaccineCentre_VaccineCentreId",
                        column: x => x.VaccineCentreId,
                        principalTable: "VaccineCentre",
                        principalColumn: "VaccineCentreId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Quota_VaccineCentreId",
                table: "Quota",
                column: "VaccineCentreId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Quota");
        }
    }
}
