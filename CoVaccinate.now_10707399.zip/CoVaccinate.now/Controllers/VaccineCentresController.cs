﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CoVaccinate.now.Data;
using CoVaccinate.now.Models;
using Microsoft.AspNetCore.Authorization;

namespace CoVaccinate.now.Controllers
{
    [Authorize(Roles = "User")]
    public class VaccineCentresController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VaccineCentresController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: VaccineCentres
        public async Task<IActionResult> Index()
        {
            return View(await _context.VaccineCentre.ToListAsync());
        }

        // GET: VaccineCentres/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vaccineCentre = await _context.VaccineCentre
                .FirstOrDefaultAsync(m => m.VaccineCentreId == id);
            if (vaccineCentre == null)
            {
                return NotFound();
            }

            return View(vaccineCentre);
        }

        private bool VaccineCentreExists(int id)
        {
            return _context.VaccineCentre.Any(e => e.VaccineCentreId == id);
        }

        public IActionResult Locate()
        {
            return View();
        }
    }
}
