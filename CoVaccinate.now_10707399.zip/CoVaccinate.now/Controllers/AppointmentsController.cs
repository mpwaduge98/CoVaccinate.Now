﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CoVaccinate.now.Data;
using CoVaccinate.now.Models;

using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

using Twilio.TwiML;
using Microsoft.AspNetCore.Authorization;


namespace CoVaccinate.now.Controllers
{
    [Authorize(Roles = "User")]
    public class AppointmentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AppointmentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Appointments
        public async Task<IActionResult> Index()
        {
            return View(await _context.AppointmentModel.ToListAsync());
        }


        // GET: Appointments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointmentModel = await _context.AppointmentModel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (appointmentModel == null)
            {
                return NotFound();
            }

            return View(appointmentModel);
        }

        // GET: Appointments/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Appointments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,FirstName,LastName,DOB,Gender,NIC,Address,PhoneNumber,AppointmentDate,VaccineName,VaccineDose,VaccineCentreName")] AppointmentModel appointmentModel)
        {
            if (ModelState.IsValid)
            {
                //account Sid and Auth Token of Twilio
                const string accountSid = "AC5dbb1760e329719340b366b6f082c772";
                const string authToken = "040932a28dd1939735bec28c0daa05a2";
                TwilioClient.Init(accountSid, authToken);

                var to = new PhoneNumber("+94" + appointmentModel.PhoneNumber);
                var message = MessageResource.Create(

                    to,
                    from: new PhoneNumber("+19362274951"),
                    body: $"Hello, { appointmentModel.FirstName } ! You have an appointment on { appointmentModel.AppointmentDate } at { appointmentModel.VaccineCentreName } for { appointmentModel.VaccineName } , { appointmentModel.VaccineDose } Thank you for Registering with CoVaccinate.now. Stay safe!"
                    );

                _context.Add(appointmentModel);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            else
            {
                return View(appointmentModel);
            }
           
        }

        // GET: Appointments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointmentModel = await _context.AppointmentModel.FindAsync(id);
            if (appointmentModel == null)
            {
                return NotFound();
            }
            return View(appointmentModel);
        }

        // POST: Appointments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FirstName,LastName,DOB,Gender,NIC,Address,PhoneNumber,AppointmentDate,VaccineName,VaccineDose,VaccineCentreName")] AppointmentModel appointmentModel)
        {
            if (id != appointmentModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(appointmentModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AppointmentModelExists(appointmentModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(appointmentModel);
        }

        // GET: Appointments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointmentModel = await _context.AppointmentModel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (appointmentModel == null)
            {
                return NotFound();
            }

            return View(appointmentModel);
        }

        // POST: Appointments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var appointmentModel = await _context.AppointmentModel.FindAsync(id);
            _context.AppointmentModel.Remove(appointmentModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AppointmentModelExists(int id)
        {
            return _context.AppointmentModel.Any(e => e.Id == id);
        }

        [HttpPost]
        public JsonResult AutoComplete(string Prefix)
        {
            var VaccineList = (from N in _context.Vaccine.ToList()
                               where N.VaccineName.StartsWith(Prefix)
                               select new { N.VaccineName });
            return Json(VaccineList);
        }


    }
}
