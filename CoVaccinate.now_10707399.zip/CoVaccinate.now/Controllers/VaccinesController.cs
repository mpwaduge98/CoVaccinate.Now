﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CoVaccinate.now.Data;
using CoVaccinate.now.Models;
using Microsoft.AspNetCore.Authorization;

namespace CoVaccinate.now.Controllers
{
    [Authorize(Roles = "User")]
    public class VaccinesController : Controller
    {
        private readonly ApplicationDbContext _context;


        public VaccinesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Vaccines
        public async Task<IActionResult> Index(string VaccineName)
        {
            if (String.IsNullOrEmpty(VaccineName))
            {
                var applicationDbContext = _context.Vaccine.Include(v => v.AgeGroup).Include(v => v.VaccineDose);
                return View(await applicationDbContext.ToListAsync());
            }
            else
            {
                var searchItems = await _context.Vaccine.Include(v => v.AgeGroup).Include(v => v.VaccineDose).Where(s => s.VaccineName.Contains(VaccineName)).ToListAsync();
                return View(searchItems);
            }

        }

        // GET: Vaccines/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vaccine = await _context.Vaccine
                .Include(v => v.AgeGroup)
                .Include(v => v.VaccineDose)
                .FirstOrDefaultAsync(m => m.VaccineID == id);
            if (vaccine == null)
            {
                return NotFound();
            }

            return View(vaccine);
        }

        private bool VaccineExists(int id)
        {
            return _context.Vaccine.Any(e => e.VaccineID == id);
        }
    }
}
