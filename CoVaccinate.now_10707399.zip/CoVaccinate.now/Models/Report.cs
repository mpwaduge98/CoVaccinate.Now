﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CoVaccinate.now.Models
{
    public class Report
    {
        [Key]
        public int ReportId { get; set; }

        [Display(Name = "Appointment ID")]
        [Required]
        public int Id { get; set; }

        [Display(Name ="Appointment Status")]
        [Required]
        public Status? Status { get; set; }

        [ForeignKey("Id")]
        public virtual AppointmentModel AppointmentModel { get; set; }
    }
}

namespace CoVaccinate.now
{
    public enum Status
    {
        None,
        Attended,
        Declined
    }
}
