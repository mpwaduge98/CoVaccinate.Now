﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoVaccinate.now.Models
{
    public class VaccineCentre
    {
        [Key]
        public int VaccineCentreId { get; set; }

        [Required]
        [Display(Name = "Name of Vaccine Centre")]
        public string VaccineCentreName { get; set; }

        [Required]
        [Display(Name = "Address")]
        public string Address { get; set; }

        [Required]
        public string ZIPCode { get; set; }

        [Required]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Phone Number")]
        public int PhoneNo { get; set; }

        public string longitude { get; set; }

        public string latitude { get; set; }

        public VaccineCentre()
        {
                
        }
    }
}
