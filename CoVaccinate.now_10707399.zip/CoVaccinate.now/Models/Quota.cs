﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CoVaccinate.now.Models
{
    public class Quota
    {
        [Key]
        public int QuotaID { get; set; }

        [DisplayName("Vaccine Centre Name")]
        [Required]
        public int VaccineCentreId { get; set; }

        [ForeignKey("VaccineCentreId")]
        public virtual VaccineCentre VaccineCentre { get; set; }

        [DisplayName("Open Days")]
        [Required]
        public string OpenDays { get; set; }

        [DisplayName("Open Hours")]
        [Required]
        public string OpenHours { get; set; }
    }
}
