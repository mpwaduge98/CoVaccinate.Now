﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CoVaccinate.now.Models
{
    public class AppointmentModel
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name ="First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }

        [Required]
        [Display(Name = "Gender")]
        public string Gender { get; set; }

        [Required]
        [Display(Name = "NIC No.")]
        public string NIC { get; set; }

        [Required]
        [Display(Name = "Address")]
        public string Address { get; set; }

        [Required, Phone, Display(Name = "Phone number")]
        public string PhoneNumber { get; set; }

        [Required]
        [Display(Name ="Appointment Date")]
        public DateTime AppointmentDate { get; set; }

        [Required(ErrorMessage = "Enter a Vaccine Name")]
        [Display(Name = "Vaccine")]
        public string VaccineName { get; set; }
        
        [Required(ErrorMessage = "Enter the Vaccine Dose")]
        [Display(Name = "Vaccine Dose")]
        public string VaccineDose { get; set; }

        [Required(ErrorMessage = "Enter the Vaccine Centre Name")]
        [Display(Name = "Vaccine Centre")]
        public string VaccineCentreName { get; set; }

    }
}
