﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CoVaccinate.now.Models
{
    public class Vaccine
    {
        [Key]
        public int VaccineID { get; set; }

        [DisplayName("Vaccine Name")]
        [Required]
        public string VaccineName { get; set; }

        [DisplayName("Age Group")]
        [Required(ErrorMessage = "Please select a Age Group") ]
        public int AgeGroupId { get; set; }

        [DisplayName("Vaccine Dose")]
        [Required(ErrorMessage = "Please select a Vaccine Dose")]
        public int VaccineDoseId { get; set; }

        [DisplayName("Special Note")]
        public string SpecialNote { get; set; }

        [ForeignKey("AgeGroupId")]
        public virtual AgeGroup AgeGroup { get; set; }

        [ForeignKey("VaccineDoseId")]
        public virtual VaccineDose VaccineDose { get; set; }

    }
}
