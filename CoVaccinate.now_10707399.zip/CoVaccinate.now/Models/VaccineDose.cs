﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoVaccinate.now.Models
{
    public class VaccineDose
    {
        [Key]
        public int VaccineDoseId { get; set; }

        [DisplayName("Vaccine Dose")]
        [Required]
        public string VaccineDoses { get; set; }

    }
}
